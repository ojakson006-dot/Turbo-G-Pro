package com.turbo.game

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import org.json.JSONObject

private class MaxScroll(c: Context, val maxH: () -> Int) : ScrollView(c) {
    override fun onMeasure(w: Int, h: Int) {
        super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(maxH(), View.MeasureSpec.AT_MOST))
    }
}

class OverlayService : Service() {
    private val AMBER = 0xFFFFB547.toInt()
    private val RED = 0xFFFF6B86.toInt()
    private val TXT = 0xFFF1EFFF.toInt()

    private var wm: WindowManager? = null
    private var lp: WindowManager.LayoutParams? = null
    private var box: LinearLayout? = null
    private var bubble: TextView? = null
    private var bg: GradientDrawable? = null
    private var scroll: MaxScroll? = null
    private var info: TextView? = null
    private val h = Handler(Looper.getMainLooper())
    private val ex = Executors.newSingleThreadExecutor()
    private var pkg = ""
    private var name = ""
    private var heat = 0
    private var root = false
    private var wantFps = true
    private var fpsVal = -1
    private var fpsMsg = "FPS real: iniciando…"
    private var layer: String? = null
    private var prevFilter = -1
    private var running = true
    private var last: JSONObject? = null
    private var lastFrameT = 0L

    private val statTick = object : Runnable {
        override fun run() {
            if (!running) return
            render(Sys.stats(this@OverlayService))
            h.postDelayed(this, 1500)
        }
    }
    private val fpsTick = object : Runnable {
        override fun run() {
            if (!running) return
            try {
                ex.execute { readFps() }
            } catch (e: Exception) {
            }
            h.postDelayed(this, 1000)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(m: String) = h.post { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "stop") {
            stopSelf()
            return START_NOT_STICKY
        }
        pkg = i?.getStringExtra("pkg") ?: ""
        name = i?.getStringExtra("name") ?: ""
        heat = i?.getIntExtra("heat", 0) ?: 0
        root = i?.getBooleanExtra("root", false) == true
        wantFps = i?.getBooleanExtra("fps", true) == true
        fpsVal = -1
        layer = null
        lastFrameT = 0L
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("tg", "Turbo Game", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction("stop"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "tg")
            .setContentTitle("Turbo Game ativo")
            .setContentText(name)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Parar", stop).build())
            .build()
        startForeground(1, n)
        val dnd = i?.getBooleanExtra("dnd", false) == true && nm.isNotificationPolicyAccessGranted
        if (dnd && prevFilter == -1) {
            prevFilter = nm.currentInterruptionFilter
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        }
        if (box == null) build(i?.getBooleanExtra("awake", false) == true, dnd, i?.getBooleanExtra("perf", false) == true)
        h.removeCallbacks(statTick)
        h.removeCallbacks(fpsTick)
        h.post(statTick)
        h.post(fpsTick)
        return START_NOT_STICKY
    }

    private fun label(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.setTextColor(AMBER)
        v.textSize = 12f
        v.setTypeface(null, Typeface.BOLD)
        v.setPadding(0, dp(10), 0, dp(2))
        return v
    }

    private fun button(t: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setOnClickListener { f() }
        return b
    }

    /** Switch que desfaz sozinho se a ação falhar: f(novoValor, desfazer) */
    private fun sw(text: String, on: Boolean, enabled: Boolean, f: (Boolean, () -> Unit) -> Unit): Switch {
        val s = Switch(this)
        s.text = text
        s.textSize = 13f
        s.setTextColor(TXT)
        s.isChecked = on
        s.isEnabled = enabled
        var guard = false
        s.setOnCheckedChangeListener { _, v ->
            if (!guard) f(v) {
                guard = true
                s.isChecked = !v
                guard = false
            }
        }
        return s
    }

    private fun setAwake(v: Boolean) {
        val p = lp ?: return
        p.flags = if (v) p.flags or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        else p.flags and WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON.inv()
        box?.let { wm?.updateViewLayout(it, p) }
        Opts.put(this, "awake", v)
    }

    private fun setDnd(v: Boolean, undo: () -> Unit) {
        val nm = getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            if (v) {
                undo()
                toast("Permita o acesso a Não perturbar")
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            return
        }
        if (v) {
            if (prevFilter == -1) prevFilter = nm.currentInterruptionFilter
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        } else {
            nm.setInterruptionFilter(if (prevFilter != -1) prevFilter else NotificationManager.INTERRUPTION_FILTER_ALL)
            prevFilter = -1
        }
        Opts.put(this, "dnd", v)
    }

    private fun build(awake: Boolean, dndOn: Boolean, perfOn: Boolean) {
        val w = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = w
        val b = LinearLayout(this)
        b.orientation = LinearLayout.VERTICAL

        // Ícone: ⚡ + FPS real
        val bt = TextView(this)
        bt.text = "⚡"
        bt.textSize = 15f
        bt.setTypeface(null, Typeface.BOLD)
        bt.setTextColor(0xFF1A1838.toInt())
        bt.gravity = Gravity.CENTER
        bt.minWidth = dp(46)
        bt.setPadding(dp(12), 0, dp(12), 0)
        val d = GradientDrawable()
        d.cornerRadius = dp(20).toFloat()
        d.setColor(AMBER)
        bt.background = d
        bg = d
        bubble = bt
        b.addView(bt, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(40)))

        // Painel de otimização
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        p.setPadding(dp(12), dp(10), dp(12), dp(10))
        val pd = GradientDrawable()
        pd.setColor(0xF0201D40.toInt())
        pd.cornerRadius = dp(14).toFloat()
        p.background = pd
        val t = TextView(this)
        t.setTextColor(TXT)
        t.textSize = 13f
        info = t
        p.addView(t)

        val canSet = Priv.secure(this) || root
        p.addView(label("Otimização"))
        p.addView(sw("Tela sempre ligada", awake, true) { v, _ -> setAwake(v) })
        p.addView(sw("Não perturbar", dndOn, true) { v, undo -> setDnd(v, undo) })
        p.addView(sw(if (canSet) "Animações 0,5×" else "🔒 Animações 0,5× (precisa de permissão)", Priv.animOn(this), canSet) { v, undo ->
            ex.execute {
                val ok = Priv.setAnim(this, v)
                h.post { if (!ok) undo() }
            }
        })
        p.addView(sw(if (root) "Modo desempenho do jogo" else "🔒 Modo desempenho (precisa de root)", perfOn, root) { v, _ ->
            ex.execute { Sh.run("cmd game mode ${if (v) "performance" else "standard"} $pkg") }
        })

        p.addView(label("Alerta de calor"))
        val hr = LinearLayout(this)
        hr.orientation = LinearLayout.HORIZONTAL
        val opts = listOf(0 to "Off", 40 to "40°", 43 to "43°", 46 to "46°")
        val bs = ArrayList<Button>()
        fun mark() {
            opts.forEachIndexed { k, o -> bs[k].alpha = if (heat == o.first) 1f else 0.45f }
        }
        for (o in opts) {
            val bb = Button(this)
            bb.text = o.second
            bb.isAllCaps = false
            bb.textSize = 12f
            bb.minWidth = 0
            bb.minimumWidth = 0
            bb.setPadding(0, 0, 0, 0)
            bb.setOnClickListener {
                heat = o.first
                Opts.put(this, "heaton", o.first != 0)
                if (o.first != 0) Opts.put(this, "heat", o.first)
                mark()
                render(null)
            }
            bs.add(bb)
            hr.addView(bb, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        }
        mark()
        p.addView(hr)

        p.addView(label("Limpeza"))
        p.addView(button("Limpar RAM agora") {
            Thread {
                val r = Sys.cleanRam(this, pkg)
                toast("${r.optLong("mb")} MB de RAM liberados")
            }.start()
        })
        p.addView(button("Limpar cache do sistema") {
            Thread {
                val r = Sys.cleanSys(this)
                toast("${r.optLong("mb")} MB de cache liberados")
            }.start()
        })
        p.addView(button("Fechar ícone") { stopSelf() })

        val sc = MaxScroll(this) { (resources.displayMetrics.heightPixels * 0.6).toInt() }
        sc.addView(p, FrameLayout.LayoutParams(dp(250), FrameLayout.LayoutParams.WRAP_CONTENT))
        sc.visibility = View.GONE
        scroll = sc
        val slp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        slp.topMargin = dp(6)
        b.addView(sc, slp)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                (if (awake) WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON else 0),
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        params.y = dp(140)
        lp = params
        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        bt.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = params.x
                    sy = params.y
                    tx = e.rawX
                    ty = e.rawY
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) moved = true
                    params.x = sx + dx.toInt()
                    params.y = sy + dy.toInt()
                    w.updateViewLayout(b, params)
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        sc.visibility = if (sc.visibility == View.GONE) View.VISIBLE else View.GONE
                        render(null)
                    }
                }
            }
            true
        }
        w.addView(b, params)
        box = b
    }

    private fun readFps() {
        if (!wantFps) {
            fpsVal = -1
            fpsMsg = "FPS real: desativado nas opções"
            h.post { render(null) }
            return
        }
        if (root) {
            readFpsRoot()
        } else if (CaptureService.active) {
            val now = SystemClock.elapsedRealtime()
            val n = CaptureService.frames.getAndSet(0)
            if (lastFrameT != 0L && now > lastFrameT) fpsVal = Math.round(n * 1000f / (now - lastFrameT))
            lastFrameT = now
        } else {
            fpsVal = -1
            fpsMsg = "FPS real: captura de tela não autorizada"
        }
        h.post { render(null) }
    }

    private fun readFpsRoot() {
        var l = layer
        if (l == null) {
            val names = (Sh.run("dumpsys SurfaceFlinger --list") ?: "").lines().map { it.trim() }.filter { it.contains(pkg) }
            l = names.firstOrNull { it.contains("SurfaceView") && it.contains("BLAST") }
                ?: names.firstOrNull { it.contains("SurfaceView") }
                ?: names.firstOrNull()
        }
        if (l == null) {
            fpsVal = -1
            fpsMsg = "FPS real: aguardando o jogo"
            return
        }
        layer = l
        val out = Sh.run("dumpsys SurfaceFlinger --latency '$l'") ?: return
        val ts = out.lines().drop(1)
            .mapNotNull { it.trim().split(Regex("\\s+")).getOrNull(1)?.toLongOrNull() }
            .filter { it > 0 && it < Long.MAX_VALUE / 2 }
        if (ts.size < 2) {
            layer = null
            return
        }
        val sec = (ts.last() - ts.first()) / 1e9
        if (sec > 0) fpsVal = Math.round((ts.size - 1) / sec).toInt()
    }

    private fun render(s: JSONObject?) {
        if (s != null) last = s
        val j = last ?: return
        val temp = j.optDouble("temp")
        val hot = heat > 0 && temp >= heat
        bg?.setColor(if (hot) RED else AMBER)
        val bt = if (fpsVal >= 0) "⚡ $fpsVal" else "⚡"
        if (bubble?.text?.toString() != bt) bubble?.text = bt
        if (scroll?.visibility != View.VISIBLE) return
        val warn = if (hot) "\n⚠ Quente! Limite de $heat °C" else ""
        val fpsLine = if (fpsVal >= 0) "FPS real: $fpsVal" else fpsMsg
        val txt = name + "\n" + fpsLine + "\nRAM em uso: " + j.optInt("ram") + "% · livre " + j.optInt("free") +
            " MB\nTemperatura: " + temp + " °C\nBateria: " + j.optInt("bat") + "%" + warn
        if (info?.text?.toString() != txt) info?.text = txt
    }

    override fun onDestroy() {
        running = false
        h.removeCallbacksAndMessages(null)
        try {
            box?.let { wm?.removeView(it) }
        } catch (e: Exception) {
        }
        if (prevFilter != -1) getSystemService(NotificationManager::class.java).setInterruptionFilter(prevFilter)
        stopService(Intent(this, CaptureService::class.java))
        ex.shutdown()
        super.onDestroy()
    }
}

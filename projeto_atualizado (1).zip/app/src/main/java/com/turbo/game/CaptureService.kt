package com.turbo.game

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import java.util.concurrent.atomic.AtomicInteger

/**
 * FPS real sem root: espelha a tela num display virtual minúsculo e conta quantos quadros
 * novos o Android entrega por segundo (só muda o quadro quando o jogo desenha algo novo).
 * Nenhuma imagem é lida nem salva: só contamos quadros.
 */
class CaptureService : Service() {
    companion object {
        val frames = AtomicInteger(0)
        @Volatile var active = false
    }

    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var ht: HandlerThread? = null

    override fun onBind(i: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    private fun dataOf(i: Intent?): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i?.getParcelableExtra("data", Intent::class.java) else i?.getParcelableExtra("data")

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("tg", "Turbo Game", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "tg")
            .setContentTitle("Turbo Game medindo FPS")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
            else startForeground(2, n)
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        val code = i?.getIntExtra("code", 0) ?: 0
        val data = dataOf(i)
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val p = mpm.getMediaProjection(code, data)
            val t = HandlerThread("tg-cap")
            t.start()
            ht = t
            val hd = Handler(t.looper)
            // Android 14+: o callback precisa existir antes de criar o display virtual
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    active = false
                    stopSelf()
                }
            }, hd)
            proj = p
            val dm = resources.displayMetrics
            val k = maxOf(1, maxOf(dm.widthPixels, dm.heightPixels) / 240)
            val w = maxOf(16, dm.widthPixels / k)
            val h = maxOf(16, dm.heightPixels / k)
            val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            r.setOnImageAvailableListener({ rd ->
                frames.incrementAndGet()
                try {
                    rd.acquireLatestImage()?.close()
                } catch (e: Exception) {
                }
            }, hd)
            reader = r
            frames.set(0)
            vd = p.createVirtualDisplay("tg-fps", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null)
            active = true
        } catch (e: Exception) {
            active = false
            stopSelf()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        active = false
        try { vd?.release() } catch (e: Exception) {}
        try { reader?.close() } catch (e: Exception) {}
        try { proj?.stop() } catch (e: Exception) {}
        try { ht?.quitSafely() } catch (e: Exception) {}
        super.onDestroy()
    }
}

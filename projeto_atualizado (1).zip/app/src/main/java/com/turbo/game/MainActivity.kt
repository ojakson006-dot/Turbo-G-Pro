package com.turbo.game

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var pending: Pending? = null

    private class Pending(val pkg: String, val name: String, val o: JSONObject, val li: Intent, val root: Boolean)

    private val OK = "{\"ok\":true}"

    private fun open(a: String, u: String?) {
        val i = Intent(a)
        if (u != null) i.data = Uri.parse(u)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runOnUiThread { startActivity(i) }
    }

    private fun js(code: String) {
        runOnUiThread { if (::web.isInitialized) web.evaluateJavascript(code, null) }
    }

    /** Avisa a tela do resultado de um código: onRun(id, deuCerto, texto) */
    private fun done(id: String, ok: Boolean, msg: String) {
        js("onRun(${JSONObject.quote(id)},$ok,${JSONObject.quote(msg)})")
    }

    private fun safeOpen(a: String, u: String?): Boolean = try {
        val i = Intent(a)
        if (u != null) i.data = Uri.parse(u)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runOnUiThread {
            try {
                startActivity(i)
            } catch (e: Exception) {
                js("toast('Não consegui abrir')")
            }
        }
        true
    } catch (e: Exception) {
        false
    }

    private val shzListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        bg {
            Sh.soft()
            js("window.sync&&sync()")
        }
    }

    private fun bg(f: () -> Unit) {
        Thread {
            try {
                f()
            } catch (e: Exception) {
            }
        }.start()
    }

    /** Prepara o aparelho, sobe o ícone flutuante (com a captura de FPS, se houver) e abre o app. */
    private fun go(p: Pending, code: Int, data: Intent?) {
        val o = p.o
        bg {
            if (o.flag("ram")) Sys.cleanRam(this, p.pkg)
            if (o.flag("cache")) Sys.cleanSys(this)
            if (o.flag("bat") && Priv.canSet(this)) Priv.batteryOff(this)
            if (p.root) {
                if (o.flag("perf")) Sh.run("cmd game mode performance ${p.pkg}")
                if (o.flag("comp")) bg { Sh.run("cmd package compile -m speed-profile -f ${p.pkg}") }
            }
            runOnUiThread {
                if (o.flag("ov", true)) {
                    if (data != null) {
                        startForegroundService(
                            Intent(this, CaptureService::class.java).putExtra("code", code).putExtra("data", data)
                        )
                    }
                    startForegroundService(
                        Intent(this, OverlayService::class.java)
                            .putExtra("pkg", p.pkg)
                            .putExtra("name", p.name)
                            .putExtra("awake", o.flag("awake"))
                            .putExtra("dnd", o.flag("dnd"))
                            .putExtra("perf", o.flag("perf") && p.root)
                            .putExtra("fps", o.flag("fps", true))
                            .putExtra("root", p.root)
                            .putExtra("heat", o.optInt("heat", 0))
                    )
                }
                startActivity(p.li)
            }
        }
    }

    inner class Bridge {
        /** Todos os apps que têm ícone na tela inicial; jogos primeiro. [nome, pacote, éJogo] */
        @JavascriptInterface
        fun apps(): String {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val seen = HashSet<String>()
            val list = ArrayList<Triple<String, String, Boolean>>()
            for (r in pm.queryIntentActivities(q, 0)) {
                val ai = r.activityInfo.applicationInfo
                val p = ai.packageName
                if (p == packageName || !seen.add(p)) continue
                @Suppress("DEPRECATION")
                val g = (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0 || ai.category == ApplicationInfo.CATEGORY_GAME
                list.add(Triple(r.loadLabel(pm).toString(), p, g))
            }
            list.sortWith(compareBy<Triple<String, String, Boolean>>({ !it.third }, { it.first.lowercase() }))
            val out = JSONArray()
            list.forEach { out.put(JSONArray().put(it.first).put(it.second).put(it.third)) }
            return out.toString()
        }

        @JavascriptInterface
        fun stats(): String = Sys.stats(this@MainActivity).toString()

        @JavascriptInterface
        fun getOpts(): String = Opts.get(this@MainActivity).toString()

        @JavascriptInterface
        fun setOpts(s: String): String {
            try {
                Opts.set(this@MainActivity, JSONObject(s))
            } catch (e: Exception) {
            }
            return OK
        }

        @JavascriptInterface
        fun root(): String = (Sh.peek() == true).toString()

        /** Estado real de tudo que o app precisa. root = null enquanto ainda verifica. */
        @JavascriptInterface
        fun priv(): String {
            val c = this@MainActivity
            val nm = getSystemService(NotificationManager::class.java)
            val notif = if (Build.VERSION.SDK_INT >= 33)
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED else true
            val o = JSONObject()
            o.put("root", Sh.peek() ?: JSONObject.NULL)
            o.put("secure", Priv.secure(c))
            o.put("overlay", Settings.canDrawOverlays(c))
            o.put("dnd", nm.isNotificationPolicyAccessGranted)
            o.put("notif", notif)
            o.put("anim", Priv.animOn(c))
            o.put("mode", Sh.mode)
            o.put("pref", Sh.pref())
            o.put("shz", ShizukuSh.state(c))
            o.put("wifi", WifiAdb.state(c))
            o.put("sdk", Build.VERSION.SDK_INT)
            return o.toString()
        }

        @JavascriptInterface
        fun openPerm(k: String): String {
            when (k) {
                "overlay" -> open(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, "package:$packageName")
                "dnd" -> open(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS, null)
                "notif" -> runOnUiThread {
                    if (Build.VERSION.SDK_INT >= 33) {
                        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 5)
                    } else {
                        startActivity(
                            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                .putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                        )
                    }
                }
            }
            return OK
        }

        @JavascriptInterface
        fun setAnim(on: Boolean): String {
            val ok = Priv.canSet(this@MainActivity) && Priv.setAnim(this@MainActivity, on)
            return JSONObject().put("ok", ok).toString()
        }

        @JavascriptInterface
        fun cleanRam(): String {
            bg {
                val r = Sys.cleanRam(this@MainActivity)
                js("onDone('ram',$r)")
            }
            return OK
        }

        @JavascriptInterface
        fun cleanSys(): String {
            bg {
                val r = Sys.cleanSys(this@MainActivity)
                js("onDone('sys',$r)")
            }
            return OK
        }

        @JavascriptInterface
        fun cleanAll(): String {
            bg {
                val r = Sys.cleanRam(this@MainActivity)
                val s = Sys.cleanSys(this@MainActivity)
                val own = Sys.cleanOwn(this@MainActivity)
                val o = JSONObject().put("ram", r.optLong("mb")).put("sys", s.optLong("mb")).put("own", own)
                js("onDone('all',$o)")
            }
            return OK
        }

        @JavascriptInterface
        fun cleanOwn(): String = JSONObject().put("mb", Sys.cleanOwn(this@MainActivity)).toString()

        @JavascriptInterface
        fun copy(t: String): String {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            runOnUiThread { cm.setPrimaryClip(ClipData.newPlainText("codigo", t)) }
            return "true"
        }

        /** Comandos que precisam de root, Shizuku ou Wi-Fi (rodam pelo caminho em uso). */
        private fun shellFor(id: String): String? = when (id) {
            "dex" -> "cmd package compile -m speed-profile -a"
            "bg" -> "cmd package bg-dexopt-job"
            "idle" -> "sm idle-maint run"
            "speed" -> "cmd package compile -m speed -a"
            "dexreset" -> "cmd package compile --reset -a"
            "doze" -> "dumpsys deviceidle whitelist +$packageName"
            "doze0" -> "dumpsys deviceidle whitelist -$packageName"
            "wifill" -> "cmd wifi force-low-latency-mode enabled"
            "wifill0" -> "cmd wifi force-low-latency-mode disabled"
            "grant" -> "pm grant $packageName android.permission.WRITE_SECURE_SETTINGS"
            "drop" -> "sync; echo 3 > /proc/sys/vm/drop_caches"
            else -> null
        }

        private fun looksBad(out: String): Boolean =
            Regex("(?i)(exception|error:|denied|not found|unknown command|usage:)").containsMatchIn(out)

        @JavascriptInterface
        fun runCode(id: String): String {
            val c = this@MainActivity
            val adv = "{\"ok\":false,\"need\":\"adv\"}"
            val sh = "{\"ok\":false,\"need\":\"shell\"}"
            when (id) {
                "anim", "anim0", "anim_off" -> {
                    if (!Priv.canSet(c)) return adv
                    bg {
                        val v = when (id) {
                            "anim" -> "0.5"
                            "anim0" -> "1.0"
                            else -> "0"
                        }
                        val ok = listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")
                            .map { Priv.putGlobal(c, it, v) }.all { it }
                        done(id, ok, if (ok) "Animações em ${v}×" else "Não consegui mudar as animações")
                        js("sync()")
                    }
                    return OK
                }
                "lowpower" -> {
                    if (!Priv.canSet(c)) return adv
                    bg {
                        val ok = Priv.putGlobal(c, "low_power", "0")
                        done(id, ok, if (ok) "Economia de bateria desligada" else "Não consegui mudar")
                    }
                    return OK
                }
                "kill" -> {
                    bg {
                        val r = Sys.cleanRam(c)
                        done(id, true, "${r.optLong("mb")} MB de RAM liberados")
                    }
                    return OK
                }
                "trim" -> {
                    bg {
                        val r = Sys.cleanSys(c)
                        done(id, true, "${r.optLong("mb")} MB de cache liberados")
                    }
                    return OK
                }
            }
            val cmd = shellFor(id) ?: return "{\"ok\":false}"
            if (id == "drop" && Sh.hasRoot() && Sh.mode != Sh.ROOT) return "{\"ok\":false,\"need\":\"root\"}"
            if (!Sh.hasRoot()) return sh
            bg {
                val out = Sh.run(cmd)
                if (out == null) {
                    done(id, false, "Sem resposta: a conexão caiu? Veja a seção Conexão")
                } else {
                    val t = out.trim()
                    done(id, !looksBad(t), if (t.isEmpty()) "Executado" else t)
                    if (id == "grant") js("sync()")
                }
            }
            return OK
        }

        /** Código digitado pelo usuário na aba Códigos. */
        @JavascriptInterface
        fun exec(cmd: String): String {
            if (cmd.isBlank()) return "{\"ok\":false}"
            if (!Sh.hasRoot()) return "{\"ok\":false,\"need\":\"shell\"}"
            bg {
                val out = Sh.run(cmd)
                if (out == null) {
                    done("custom", false, "Sem resposta: a conexão caiu? Veja a seção Conexão")
                } else {
                    val t = out.trim()
                    done("custom", true, if (t.isEmpty()) "Executado (sem saída)" else t)
                }
            }
            return OK
        }

        /** Escolhe o caminho: 0 automático, 1 root, 2 Shizuku, 3 Depuração por Wi-Fi. */
        @JavascriptInterface
        fun setMode(m: Int): String {
            Sh.setPref(m)
            bg {
                Sh.detect()
                js("window.sync&&sync()")
            }
            return OK
        }

        @JavascriptInterface
        fun recheck(): String {
            bg {
                Sh.detect()
                js("window.sync&&sync()")
            }
            return OK
        }

        /** Ação do botão do Shizuku, conforme o estado dele. */
        @JavascriptInterface
        fun shizuku(): String {
            val c = this@MainActivity
            val st = ShizukuSh.state(c)
            when (st) {
                0 -> if (!safeOpen(Intent.ACTION_VIEW, "market://details?id=${ShizukuSh.PKG}")) {
                    safeOpen(Intent.ACTION_VIEW, "https://play.google.com/store/apps/details?id=${ShizukuSh.PKG}")
                }
                1 -> {
                    val li = packageManager.getLaunchIntentForPackage(ShizukuSh.PKG)
                    if (li != null) runOnUiThread { startActivity(li) }
                }
                2 -> ShizukuSh.request()
                else -> bg {
                    Sh.soft()
                    js("window.sync&&sync()")
                }
            }
            return JSONObject().put("s", st).toString()
        }

        @JavascriptInterface
        fun wifiPair(port: String, code: String): String {
            val pt = port.trim().toIntOrNull()
                ?: return "{\"ok\":false,\"msg\":\"Digite a porta do pareamento\"}"
            if (code.trim().length < 6) return "{\"ok\":false,\"msg\":\"Digite o código de 6 dígitos\"}"
            bg {
                val r = WifiAdb.pair(this@MainActivity, pt, code.trim())
                js("onConn('pair',${r.first},${JSONObject.quote(r.second)})")
            }
            return OK
        }

        @JavascriptInterface
        fun wifiConnect(port: String): String {
            val pt = port.trim().toIntOrNull()
            bg {
                val r = WifiAdb.connect(this@MainActivity, pt)
                if (r.first) Sh.detect()
                js("onConn('connect',${r.first},${JSONObject.quote(r.second)})")
            }
            return OK
        }

        @JavascriptInterface
        fun openDev(): String {
            safeOpen(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS, null)
            return OK
        }

        @JavascriptInterface
        fun clearCache(pkg: String): String {
            if (Sh.peek() == true) {
                if (Sh.mode == Sh.ROOT) {
                    bg { Sh.run("rm -rf /data/data/$pkg/cache/* /data/data/$pkg/code_cache/* /sdcard/Android/data/$pkg/cache/*") }
                } else {
                    bg { Sh.run("pm clear --cache-only $pkg") }
                }
                return OK
            }
            open(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, "package:$pkg")
            return "{\"ok\":false}"
        }

        @JavascriptInterface
        fun launch(pkg: String, name: String, opts: String): String {
            val c = this@MainActivity
            val o = JSONObject(opts)
            val useOv = o.flag("ov", true)
            if (useOv && !Settings.canDrawOverlays(c)) {
                open(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, "package:$packageName")
                return "{\"ok\":false,\"need\":\"overlay\"}"
            }
            val nm = getSystemService(NotificationManager::class.java)
            if (o.flag("dnd") && !nm.isNotificationPolicyAccessGranted) {
                open(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS, null)
                return "{\"ok\":false,\"need\":\"dnd\"}"
            }
            val li = packageManager.getLaunchIntentForPackage(pkg) ?: return "{\"ok\":false,\"need\":\"nolaunch\"}"
            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val root = Sh.peek() == true
            val p = Pending(pkg, name, o, li, root)
            // Sem root, o FPS real vem da captura de tela: o Android pede autorização a cada abertura
            if (useOv && o.flag("fps", true) && !root) {
                pending = p
                val mpm = getSystemService(MediaProjectionManager::class.java)
                val sci = if (Build.VERSION.SDK_INT >= 34)
                    mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
                else mpm.createScreenCaptureIntent()
                runOnUiThread { startActivityForResult(sci, 77) }
                return "{\"ok\":true,\"wait\":true}"
            }
            go(p, 0, null)
            return OK
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(rq: Int, rc: Int, d: Intent?) {
        super.onActivityResult(rq, rc, d)
        if (rq != 77) return
        val p = pending ?: return
        pending = null
        if (rc == RESULT_OK && d != null) {
            go(p, rc, d)
        } else {
            js("toast('Sem autorização de captura: o FPS real não vai aparecer')")
            go(p, 0, null)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Sh.init(this)
        try {
            Shizuku.addRequestPermissionResultListener(shzListener)
        } catch (e: Throwable) {
        }
        val w = WebView(this)
        web = w
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.addJavascriptInterface(Bridge(), "TG")
        w.loadUrl("file:///android_asset/index.html")
        setContentView(w)
        // verifica o root em segundo plano (o pedido do Magisk não trava a tela)
        bg {
            Sh.hasRoot()
            js("window.sync&&sync()")
        }
    }

    override fun onResume() {
        super.onResume()
        js("window.sync&&sync()")
        // voltou de outro app (Shizuku, Depuração sem fio…): confere de novo sem incomodar o root
        if (Sh.peek() == false) bg {
            Sh.soft()
            js("window.sync&&sync()")
        }
    }

    override fun onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(shzListener)
        } catch (e: Throwable) {
        }
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        moveTaskToBack(true)
    }
}
